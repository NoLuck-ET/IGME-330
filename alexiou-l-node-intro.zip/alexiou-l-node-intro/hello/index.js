console.log("Hello node!");
